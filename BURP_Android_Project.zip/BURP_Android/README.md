# BURP! Android

Progetto Android pronto da aprire in Android Studio. L'app funziona offline e contiene i 9 rutti sintetizzati; ogni pulsante può essere associato a un audio personale scelto dal telefono.

## Metodo più semplice: creare l'APK con Android Studio
1. Estrai lo ZIP.
2. Apri Android Studio e scegli **Open**.
3. Seleziona la cartella `BURP_Android`.
4. Attendi il completamento di Gradle Sync. Se richiesto, installa Android SDK 35.
5. Collega il telefono con Debug USB oppure scegli **Build > Build APK(s)**.
6. L'APK sarà in `app/build/outputs/apk/debug/app-debug.apk`.
7. Copia l'APK sul telefono, aprilo e consenti l'installazione da questa origine.

## Metodo senza Android Studio: GitHub Actions
Il progetto include `.github/workflows/build-apk.yml`. Carica tutti i file in un repository GitHub, apri **Actions > Build Android APK > Run workflow** e scarica l'artefatto `BURP-debug-apk`.

## Note
- Package: `it.alexgames.burp`
- Android minimo: 7.0 (API 24)
- Target/compile SDK: 35
- Versione: 1.0.0
- Nessun permesso Internet richiesto
- I file audio personalizzati sono salvati nel database locale della WebView.
