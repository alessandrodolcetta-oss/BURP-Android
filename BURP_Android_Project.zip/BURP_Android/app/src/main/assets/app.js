
(() => {
  "use strict";
  const sounds = [
    {id:"lion", icon:"🦁", name:"Rutto Leone", desc:"profondo e ruggente"},
    {id:"thunder", icon:"🌩️", name:"Rutto Tuono", desc:"cupo e rimbombante"},
    {id:"pig", icon:"🐷", name:"Rutto Maiale", desc:"corto, nasale e grugnente"},
    {id:"frog", icon:"🐸", name:"Rutto Rana", desc:"elastico e gracchiante"},
    {id:"cow", icon:"🐮", name:"Rutto Mucca", desc:"lungo, basso e muggente"},
    {id:"sink", icon:"🚰", name:"Rutto Lavandino", desc:"liquido e gorgogliante"},
    {id:"horse", icon:"🐴", name:"Rutto Cavallo", desc:"gutturale con labbra vibranti"},
    {id:"can", icon:"🥤", name:"Rutto Lattina", desc:"breve con apertura sibilante"},
    {id:"air", icon:"☁️", name:"Rutto Soffio", desc:"leggerissimo, quasi d’aria"}
  ];
  const grid = document.querySelector("#soundGrid");
  const status = document.querySelector("#status");
  const volume = document.querySelector("#volume");
  const stopButton = document.querySelector("#stopButton");
  const installButton = document.querySelector("#installButton");
  let ctx = null, activeNodes = [], activeAudio = null, installPrompt = null;
  let dbPromise = openDb();

  function setStatus(title, text){ status.innerHTML = `<strong>${escapeHtml(title)}</strong> ${escapeHtml(text)}`; }
  function escapeHtml(value){ const d=document.createElement("div"); d.textContent=String(value); return d.innerHTML; }
  function openDb(){ return new Promise((resolve,reject)=>{ const r=indexedDB.open("burp-soundboard",1); r.onupgradeneeded=()=>r.result.createObjectStore("audio"); r.onsuccess=()=>resolve(r.result); r.onerror=()=>reject(r.error); }); }
  async function dbGet(key){ const db=await dbPromise; return new Promise((res,rej)=>{const r=db.transaction("audio").objectStore("audio").get(key);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);}); }
  async function dbSet(key,value){ const db=await dbPromise; return new Promise((res,rej)=>{const r=db.transaction("audio","readwrite").objectStore("audio").put(value,key);r.onsuccess=()=>res();r.onerror=()=>rej(r.error);}); }
  async function dbDelete(key){ const db=await dbPromise; return new Promise((res,rej)=>{const r=db.transaction("audio","readwrite").objectStore("audio").delete(key);r.onsuccess=()=>res();r.onerror=()=>rej(r.error);}); }

  sounds.forEach(s => {
    const card=document.createElement("article"); card.className="card"; card.innerHTML=`
      <button class="sound" type="button" data-play="${s.id}" aria-label="Riproduci ${s.name}">
        <span class="icon" aria-hidden="true">${s.icon}</span><span class="name">${s.name}</span>
      </button>
      <div class="actions">
        <label class="choose"><span data-file-label="${s.id}">＋ Audio</span><input type="file" accept="audio/*" data-file="${s.id}" aria-label="Scegli file audio per ${s.name}"></label>
        <button class="reset" type="button" data-reset="${s.id}" aria-label="Ripristina ${s.name}" hidden>↺</button>
      </div>`;
    grid.append(card);
  });

  function audioContext(){ if(!ctx) ctx=new (window.AudioContext||window.webkitAudioContext)(); if(ctx.state==="suspended") ctx.resume(); return ctx; }
  function stopAll(){
    if(activeAudio){ activeAudio.pause(); activeAudio.src=""; activeAudio=null; }
    for(const node of activeNodes){ try{node.stop?.()}catch{} try{node.disconnect?.()}catch{} }
    activeNodes=[]; document.querySelectorAll(".playing").forEach(x=>x.classList.remove("playing"));
  }
  function noiseBuffer(c,duration){ const b=c.createBuffer(1,Math.ceil(c.sampleRate*duration),c.sampleRate),a=b.getChannelData(0); for(let i=0;i<a.length;i++)a[i]=Math.random()*2-1; return b; }
  function playSynth(type){
    const c=audioContext(), now=c.currentTime, out=c.createGain(), comp=c.createDynamicsCompressor();
    out.gain.value=Number(volume.value); out.connect(comp); comp.connect(c.destination); activeNodes.push(out,comp);
    const profiles={lion:[58,34,1.45,.72,7],thunder:[49,25,1.75,.86,4],pig:[128,82,.65,.55,15],frog:[105,62,.82,.52,6],cow:[67,42,1.65,.72,3],sink:[92,38,1.45,.52,11],horse:[86,51,1.05,.62,24],can:[115,72,.62,.33,9],air:[155,100,.48,.13,2]};
    const p=profiles[type], osc=c.createOscillator(), gain=c.createGain(), filter=c.createBiquadFilter();
    osc.type=type==="frog"?"square":type==="pig"?"sawtooth":"sine"; osc.frequency.setValueAtTime(p[0],now); osc.frequency.exponentialRampToValueAtTime(p[1],now+p[2]);
    filter.type="lowpass"; filter.frequency.value=type==="air"?1050:type==="can"?1500:420;
    gain.gain.setValueAtTime(.001,now); gain.gain.exponentialRampToValueAtTime(p[3],now+.045); gain.gain.exponentialRampToValueAtTime(.001,now+p[2]);
    osc.connect(filter); filter.connect(gain); gain.connect(out); osc.start(now); osc.stop(now+p[2]+.03); activeNodes.push(osc,gain,filter);
    const wob=c.createOscillator(), wobGain=c.createGain(); wob.frequency.value=p[4]; wobGain.gain.value=type==="horse"?25:type==="frog"?17:8; wob.connect(wobGain); wobGain.connect(osc.frequency); wob.start(now); wob.stop(now+p[2]); activeNodes.push(wob,wobGain);
    const noise=c.createBufferSource(), ng=c.createGain(), nf=c.createBiquadFilter(); noise.buffer=noiseBuffer(c,p[2]+.1); nf.type=(type==="can"||type==="air")?"highpass":"bandpass"; nf.frequency.value=type==="can"?2800:type==="air"?1900:type==="sink"?260:520; nf.Q.value=type==="sink"?3:1;
    ng.gain.setValueAtTime(.001,now); ng.gain.exponentialRampToValueAtTime(type==="air"?.22:type==="can"?.43:.18,now+.025); ng.gain.exponentialRampToValueAtTime(.001,now+p[2]); noise.connect(nf); nf.connect(ng); ng.connect(out); noise.start(now); noise.stop(now+p[2]+.02); activeNodes.push(noise,ng,nf);
    if(type==="sink") for(let k=0;k<5;k++){const o=c.createOscillator(),g=c.createGain(),t=now+.18+k*.22;o.frequency.value=180+Math.random()*150;g.gain.setValueAtTime(.001,t);g.gain.exponentialRampToValueAtTime(.18,t+.025);g.gain.exponentialRampToValueAtTime(.001,t+.16);o.connect(g);g.connect(out);o.start(t);o.stop(t+.18);activeNodes.push(o,g);}
    if(type==="thunder"||type==="lion"){const delay=c.createDelay(),feedback=c.createGain();delay.delayTime.value=type==="thunder"?.19:.11;feedback.gain.value=.28;gain.connect(delay);delay.connect(feedback);feedback.connect(delay);delay.connect(out);activeNodes.push(delay,feedback);}
    return p[2]*1000+150;
  }
  async function play(id,button){
    stopAll(); button.classList.add("playing"); const item=sounds.find(s=>s.id===id); setStatus(item.name+":",item.desc+".");
    try{
      const stored=await dbGet(id);
      if(stored?.blob){ const url=URL.createObjectURL(stored.blob); activeAudio=new Audio(url); activeAudio.volume=Number(volume.value); activeAudio.onended=()=>{button.classList.remove("playing");URL.revokeObjectURL(url);}; activeAudio.onerror=()=>{button.classList.remove("playing");URL.revokeObjectURL(url);setStatus("Errore.","Il file audio non può essere riprodotto.");}; await activeAudio.play(); }
      else { const ms=playSynth(id); setTimeout(()=>button.classList.remove("playing"),ms); }
    }catch(e){ button.classList.remove("playing"); setStatus("Errore.","Impossibile avviare l’audio su questo dispositivo."); }
  }
  grid.addEventListener("click",async e=>{ const playBtn=e.target.closest("[data-play]"); if(playBtn) play(playBtn.dataset.play,playBtn); const reset=e.target.closest("[data-reset]"); if(reset){stopAll();await dbDelete(reset.dataset.reset);reset.hidden=true;document.querySelector(`[data-file-label="${reset.dataset.reset}"]`).textContent="＋ Audio";setStatus("Ripristinato.","Ora viene usato il rutto sintetizzato.");}});
  grid.addEventListener("change",async e=>{ const input=e.target.closest("[data-file]"); if(!input||!input.files?.[0])return; const file=input.files[0]; if(!file.type.startsWith("audio/")){setStatus("File non valido.","Scegli un file audio.");input.value="";return;} if(file.size>20*1024*1024){setStatus("File troppo grande.","Il limite è 20 MB.");input.value="";return;} try{await dbSet(input.dataset.file,{blob:file,name:file.name,type:file.type});document.querySelector(`[data-file-label="${input.dataset.file}"]`).textContent="✓ "+file.name;document.querySelector(`[data-reset="${input.dataset.file}"]`).hidden=false;setStatus("Audio salvato.",file.name+" è pronto all’uso.");}catch{setStatus("Memoria non disponibile.","Il browser non ha potuto salvare il file.");} input.value="";});
  stopButton.addEventListener("click",()=>{stopAll();setStatus("Riproduzione fermata.","Tocca un’icona per ricominciare.");});
  volume.addEventListener("input",()=>{if(activeAudio)activeAudio.volume=Number(volume.value);});
  async function restoreLabels(){for(const s of sounds){try{const v=await dbGet(s.id);if(v){document.querySelector(`[data-file-label="${s.id}"]`).textContent="✓ "+v.name;document.querySelector(`[data-reset="${s.id}"]`).hidden=false;}}catch{}}} restoreLabels();
  window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();installPrompt=e;installButton.hidden=false;});
  installButton.addEventListener("click",async()=>{if(!installPrompt)return;installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;installButton.hidden=true;});
})();
